import requests
import streamlit as st

api_url = "http://127.0.0.1:8088"

def crud_operations():
    expense_date = st.date_input("Select the date for which expenses have to be added/updated", label_visibility="collapsed")

    response = requests.get(f"{api_url}/expenses/{expense_date}")
    if response.status_code == 200:
        expenses = response.json()
    else:
        expenses = []
        st.error(f"Unable to retrieve expenses for {expense_date}: Error {response.status_code} {response.reason}")

    categories = ["Food", "Rent", "Shopping", "Travel", "Celebration", "Other"]
    expenses_input = []
    with st.form(key="expense_form"):
        col1, col2, col3 = st.columns(3)
        with col1:
            st.text("Amount")
        with col2:
            st.text("Category")
        with col3:
            st.text("Notes")
        for i in range(5):
            if i < len(expenses):
                amount = expenses[i]["amount"]
                category = expenses[i]["category"]
                notes = expenses[i]["notes"]
            else:
                amount = 0.0
                category = "Food"
                notes = ""
            col1, col2, col3 = st.columns(3)
            with col1:
                amount_input = st.number_input("Amount", value=amount, step = 1.0, key=f"amount{i}", min_value=0.0, label_visibility="collapsed")
            with col2:
                category_input = category = st.selectbox("Category", categories, key=f"category{i}", label_visibility="collapsed", index = categories.index(category))
            with col3:
                notes_input = st.text_input("Notes", value=notes, key=f"notes{i}", label_visibility="collapsed")
            if amount_input > 0:
                expenses_input.append({
                    "amount": amount_input,
                    "category": category_input,
                    "notes": notes_input,
                })
        submit_button = st.form_submit_button()
        if submit_button:
            response = requests.post(f"{api_url}/expenses/{expense_date}", json=expenses_input)
            if response.status_code == 200:
                st.success ("Expenses updated successfully")
            else:
                st.error(f"Unable to update expense {response.status_code}")