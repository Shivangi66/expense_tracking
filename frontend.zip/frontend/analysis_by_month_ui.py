import streamlit as st
import pandas as pd
import altair as alt
import requests

api_url = "http://127.0.0.1:8088"

def analysis_by_month():
    st.title("Expense Breakdown By Month")
    response = requests.get(f"{api_url}/analytics_by_month")
    if response.status_code == 200:
        monthly_expenses = response.json()
    else:
        monthly_expenses = []
        st.error(f"Unable to retrieve monthly expenses for: Error {response.status_code} {response.reason}")

    df = pd.DataFrame(monthly_expenses)
    df_t = df.T
    df_t.sort_values("month", ascending=True, inplace=True)
    chart = alt.Chart(df_t).mark_bar().encode(
        x=alt.X("month", title="month"),
        y=alt.Y("expense", title="expense"),
    ).properties(title="Expense breakdown by month")
    st.altair_chart(chart, use_container_width=True)
    st.write(df_t)