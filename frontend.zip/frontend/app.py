import streamlit as st
from CRUD_expenses import crud_operations
from analytics_ui import analytics
from analysis_by_month_ui import analysis_by_month

st.title("Expense Tracking")

tab1, tab2, tab3 = st.tabs(["📅 Daily Expenses", "📊 Analytics", "Analytics By Month"])

with tab1:
    crud_operations()

with tab2:
    analytics()

with tab3:
    analysis_by_month()
