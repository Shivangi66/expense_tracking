from datetime import datetime
import streamlit as st
import requests
import pandas as pd
import altair as alt


api_url = "http://127.0.0.1:8088"

def analytics():
    col1, col2 = st.columns(2)
    with col1:
        start_date = st.date_input("Start date", datetime(2025, 9, 1))
    with col2:
        end_date = st.date_input("End date", datetime(2025, 9, 3))
    if st.button("Get Analytics"):
        payload = {"start_date": start_date.strftime("%Y-%m-%d"),
                   "end_date": end_date.strftime("%Y-%m-%d")}
        response = requests.post(f"{api_url}/analytics", json=payload)
        df = pd.DataFrame.from_dict(response.json())
        df_t = df.T
        st.title("Expense breakdown by category")
        chart = alt.Chart(df_t).mark_bar().encode(
            x=alt.X("category", title="category"),
            y=alt.Y("percentage", title="percentage"),
        ).properties(title="Expense breakdown")
        # st.bar_chart(df_t, width=0, height=0, use_container_width=True)
        st.altair_chart(chart, use_container_width=True)
        st.write(df_t)
        if response.status_code == 200:
            st.success(f"Analytics updated successfully")