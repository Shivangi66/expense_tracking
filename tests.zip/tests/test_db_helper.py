import pytest
from xarray.coding.cftimeindex import assert_all_valid_date_type

import backend.db_helper as db_helper
from datetime import datetime

def test_delete_expenses_for_date():
    pass

def test_insert_expense():
    db_helper.delete_expenses_for_date("1992/10/08")
    db_helper.insert_expense("1992/10/08", 10000, "Play Station", "The last of us")
    expenses = db_helper.fetch_expenses_for_date("1992/10/08")
    assert len(expenses) == 1
    assert expenses[0]["expense_date"] == datetime(1992, 10, 8)
    assert expenses[0]["amount"] == 10000
    assert expenses[0]["category"] == "Play Station"
    assert expenses[0]["notes"] == "The last of us"

def test_fetch_expenses_for_date():
    pass

def test_fetch_expense_summary():
    db_helper.delete_expenses_for_date("1992/10/08")
    db_helper.delete_expenses_for_date("1992/5/27")
    db_helper.insert_expense("1992/10/08", 10000, "Play Station", "The last of us")
    db_helper.insert_expense("1992/10/08", 1500, "Shopping", "Coffee")
    db_helper.insert_expense("1992/5/27", 5000 , "Shopping", "Birthday Dress")
    db_helper.insert_expense("1992/5/27", 250, "Others", "Miscellaneous")
    summary = db_helper.fetch_expense_summary("1992/5/27","1992/10/08")
    assert summary[0][0] == "Others"
    assert summary[0][1] == 250
    assert summary[1][0] == "Play Station"
    assert summary[1][1] == 10000
    assert summary[2][0] == "Shopping"
    assert summary[2][1] == 6500
