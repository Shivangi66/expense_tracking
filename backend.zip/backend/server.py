import datetime

from fastapi import FastAPI, HTTPException

import db_helper as db_helper
from pydantic import BaseModel
from typing import List
from typing import Optional
from setup_logger import setup_logger
from datetime import date

app = FastAPI()

logger = setup_logger("server")

class Expense(BaseModel):
    amount: float
    category: str
    notes: str

class DateRange(BaseModel):
    start_date: str
    end_date: str

@app.get("/expenses/{expense_date}", response_model = Optional[List[Expense]])
def fetch_date_expenses(expense_date: str):
    logger.debug(f"Fetching expenses for: {expense_date}")
    try:
        data = db_helper.fetch_expenses_for_date(expense_date)
        if data is None:
            raise HTTPException(status_code=500, detail="Failed to retrieve expenses from the database.")
        return data
    except Exception as e:
        return {"error": str(e)}


@app.post("/expenses/{expense_date}")
def post_date_expense(expense_date: str, expenses: List[Expense]):
    logger.debug(f"Posting expense for: {expense_date}")
    db_helper.delete_expenses_for_date(expense_date)
    for expense in expenses:
        db_helper.insert_expense(expense_date, expense.amount, expense.category, expense.notes)
    return {"message": "Expense posted"}


@app.post("/analytics/")
def get_summary(date_range: DateRange):
    percentage = {}
    data = db_helper.fetch_expense_summary(date_range.start_date, date_range.end_date)
    if data is None:
        raise HTTPException(status_code=500, detail="Failed to retrieve summary for the expenses.")
    total_expense = sum([row[1] for row in data])
    for row in data:
        percentage[row[0]] = {"category": row[0], "total": row[1], "percentage": (row[1] / total_expense) * 100}
    return percentage

@app.get("/analytics_by_month/")
def get_summary_by_month():
    month_exp = {}
    data = db_helper.fetch_expense_summary_by_month()
    if data is None:
        raise HTTPException(status_code=500, detail="Failed to retrieve summary for the expenses.")
    for row in data:
        month_exp[row[0]] = {"month": row[0], "expense": row[1]}
    return month_exp