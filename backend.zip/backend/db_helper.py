import oracledb
from contextlib import contextmanager
from setup_logger import setup_logger

oracledb.defaults.fetch_lobs = False

logger = setup_logger("db_helper")

@contextmanager
def get_cursor(commit=False):
    connection = (oracledb.connect
                  (user='<<Oracle_Username>>',
                   password='<<DB_Password>>',
                   dsn='<<Oracle_TNSEntry>>'))

    cursor = connection.cursor()

    # Set row factory to return dictionaries
    def dict_factory(cursor):
        columns = [col[0].lower() for col in cursor.description]
        return lambda *args: dict(zip(columns, args))

    yield cursor
    if commit:
        connection.commit()
    cursor.close()
    connection.close()

def log_function_calls(func):
    def wrapper(*args, **kwargs):
        logger.debug(f"Function {func.__name__} called")
        logger.debug(f"Arguments: args={args} kwargs={kwargs}")
        result = func(*args, **kwargs)
        logger.debug(f"Returned from function {func.__name__}")
        return result
    return wrapper

def fetch_all_as_dict(cursor):
    columns = [col[0].lower() for col in cursor.description]
    rows = cursor.fetchall()
    if rows:
        return [dict(zip(columns, row)) for row in rows]
    else:
        return []

@log_function_calls
def fetch_expenses_for_date(expense_date):
    with get_cursor() as cursor:
        cursor.execute("select * from expenses where expense_date = to_date(:1, 'YYYY/MM/DD')" , [expense_date])
        expenses = fetch_all_as_dict(cursor)
        return expenses

@log_function_calls
def delete_expenses_for_date(expense_date):
    with get_cursor(commit=True) as cursor:
        cursor.execute("delete from expenses where expense_date = to_date(:1, 'YYYY/MM/DD')" , [expense_date])

@log_function_calls
def insert_expense(expense_date, amount, category, notes):
    with get_cursor(commit=True) as cursor:
        cursor.execute("Insert into expenses(expense_date, amount, category, notes) values (TO_DATE(:1, 'YYYY/MM/DD'), :2, :3, :4)",
                       [expense_date, amount, category, notes])

@log_function_calls
def fetch_expense_summary(expense_date_from, expense_date_to):
    with get_cursor(commit=True) as cursor:
        fSql = "Select category, sum(amount) total_expense from expenses where expense_date between TO_DATE(:1, 'yyyy-mm-dd') and TO_DATE(:2, 'yyyy-mm-dd') group by category order by category"
        cursor.execute(fSql, [expense_date_from, expense_date_to])
        analytics = cursor.fetchall()
        return analytics

@log_function_calls
def fetch_expense_summary_by_month():
    with get_cursor(commit=True) as cursor:
        fSql = "Select to_char(expense_date,'Month') month_exp, sum(amount) total_expense from expenses group by to_char(expense_date,'Month')"
        cursor.execute(fSql)
        analytics = cursor.fetchall()
        return analytics

if __name__ == '__main__':
    #insert_expense("1992/5/27", 10000, "Another Celebration", "Birthday")
    #delete_expenses_for_date("1992/5/27")
    #expenses = fetch_expenses_for_date("1992/5/27")
    #print(expenses)
    #data = fetch_expenses_for_date("2025-09-01")
    data = fetch_expense_summary_by_month()
    print(data)